<!DOCTYPE html>
<html lang pl-PL>
    <head>
        <meta charset="UTF-8">
        <title>Zadanie na lipiec</title>
        <link rel="stylesheet" type="text/css" href="Styl2.css">
    </head>
    <body>
        <header>
            <section class="baner-1">
                <img src="logo1.png" alt="lipiec" height="140px">
            </section>
            <section class="baner-2">
                <h1>Terminarz</h1>
                <p>Najbliższe zadania:</p>
                
                <?php
                $db = mysqli_connect('localhost', 'root', '', 'terminal');
                $p = 'SELECT DISTINCT wpis FROM zadania WHERE `dataZadania` BETWEEN "2020-07-01" AND "2020-07-07" AND wpis <> ""';

                $result = mysqli_query($db, $p);
                $wpisy = "";
                while($row = mysqli_fetch_array($result)){
                    $wpisy .= $row["wpis"] ."; ";   
                }
                echo $wpisy;
                ?>

            </section>
        </header>
        
        <main>
            <?php
            $p = 'SELECT dataZadania, wpis FROM zadania WHERE miesiac="lipiec";';

            $result = mysqli_query($db, $p);
            while($row = mysqli_fetch_array($result)){
                echo '<section class="kalendarz">
                <h6>'.$row["dataZadania"].'</h6>
                <p>'.$row["wpis"].'</p>
                </section>';
            }
            ?>
            <section class="kalendarz">
                
            </section>
        </main>

        <footer>
            <h5>copyright: NULL<h5>
        </footer>
    </body>
</html>