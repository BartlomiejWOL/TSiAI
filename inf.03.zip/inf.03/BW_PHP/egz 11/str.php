<!DOCTYPE html>
<html lang="PL-pl">
    <head>
        <meta charset="UTF-8">
    </head>
    <body>
        <h1>Strona w trakcie budowy</h1>
    </body>
</html>